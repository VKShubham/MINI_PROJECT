package com.poornasapplication.app.modules.login.ui

import androidx.activity.viewModels
import com.poornasapplication.app.R
import com.poornasapplication.app.appcomponents.base.BaseActivity
import com.poornasapplication.app.databinding.ActivityLoginBinding
import com.poornasapplication.app.modules.login.`data`.viewmodel.LoginVM
import kotlin.String
import kotlin.Unit

class LoginActivity : BaseActivity<ActivityLoginBinding>(R.layout.activity_login) {
  private val viewModel: LoginVM by viewModels<LoginVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.loginVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "LOGIN_ACTIVITY"

  }
}
